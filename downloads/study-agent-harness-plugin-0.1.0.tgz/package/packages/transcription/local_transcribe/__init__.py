"""LocalTranscribe application package."""

__version__ = "1.1.0.0"
